static inline void sched_yield(void) {}
