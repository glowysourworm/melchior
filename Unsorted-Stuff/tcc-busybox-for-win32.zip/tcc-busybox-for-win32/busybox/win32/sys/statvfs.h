#include <sys/statfs.h>

#define statvfs statfs
