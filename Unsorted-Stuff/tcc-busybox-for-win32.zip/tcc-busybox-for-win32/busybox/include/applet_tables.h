/* This is a generated file, don't edit */

#define NUM_APPLETS 150
#define KNOWN_APPNAME_OFFSETS 8

const uint16_t applet_nameofs[] ALIGN2 = {
96,
188,
302,
403,
513,
632,
750,
};

const char applet_names[] ALIGN1 = ""
"[" "\0"
"[[" "\0"
"ar" "\0"
"arch" "\0"
"ash" "\0"
"awk" "\0"
"base64" "\0"
"basename" "\0"
"bash" "\0"
"bunzip2" "\0"
"busybox" "\0"
"bzcat" "\0"
"bzip2" "\0"
"cal" "\0"
"cat" "\0"
"chmod" "\0"
"cksum" "\0"
"clear" "\0"
"cmp" "\0"
"comm" "\0"
"cp" "\0"
"cpio" "\0"
"cut" "\0"
"date" "\0"
"dc" "\0"
"dd" "\0"
"df" "\0"
"diff" "\0"
"dirname" "\0"
"dos2unix" "\0"
"dpkg" "\0"
"dpkg-deb" "\0"
"du" "\0"
"echo" "\0"
"ed" "\0"
"egrep" "\0"
"env" "\0"
"expand" "\0"
"expr" "\0"
"factor" "\0"
"false" "\0"
"fgrep" "\0"
"find" "\0"
"fold" "\0"
"fsync" "\0"
"ftpget" "\0"
"ftpput" "\0"
"getopt" "\0"
"grep" "\0"
"groups" "\0"
"gunzip" "\0"
"gzip" "\0"
"hd" "\0"
"head" "\0"
"hexdump" "\0"
"iconv" "\0"
"id" "\0"
"ipcalc" "\0"
"kill" "\0"
"killall" "\0"
"less" "\0"
"link" "\0"
"ln" "\0"
"logname" "\0"
"ls" "\0"
"lzcat" "\0"
"lzma" "\0"
"lzop" "\0"
"lzopcat" "\0"
"man" "\0"
"md5sum" "\0"
"mkdir" "\0"
"mktemp" "\0"
"mv" "\0"
"nc" "\0"
"nl" "\0"
"od" "\0"
"paste" "\0"
"patch" "\0"
"pgrep" "\0"
"pidof" "\0"
"pipe_progress" "\0"
"pkill" "\0"
"printenv" "\0"
"printf" "\0"
"ps" "\0"
"pwd" "\0"
"readlink" "\0"
"realpath" "\0"
"reset" "\0"
"rev" "\0"
"rm" "\0"
"rmdir" "\0"
"rpm" "\0"
"rpm2cpio" "\0"
"sed" "\0"
"seq" "\0"
"sh" "\0"
"sha1sum" "\0"
"sha256sum" "\0"
"sha3sum" "\0"
"sha512sum" "\0"
"shred" "\0"
"shuf" "\0"
"sleep" "\0"
"sort" "\0"
"split" "\0"
"ssl_client" "\0"
"stat" "\0"
"strings" "\0"
"su" "\0"
"sum" "\0"
"tac" "\0"
"tail" "\0"
"tar" "\0"
"tee" "\0"
"test" "\0"
"timeout" "\0"
"touch" "\0"
"tr" "\0"
"true" "\0"
"truncate" "\0"
"ts" "\0"
"ttysize" "\0"
"uname" "\0"
"uncompress" "\0"
"unexpand" "\0"
"uniq" "\0"
"unix2dos" "\0"
"unlink" "\0"
"unlzma" "\0"
"unlzop" "\0"
"unxz" "\0"
"unzip" "\0"
"usleep" "\0"
"uudecode" "\0"
"uuencode" "\0"
"vi" "\0"
"watch" "\0"
"wc" "\0"
"wget" "\0"
"which" "\0"
"whoami" "\0"
"whois" "\0"
"xargs" "\0"
"xxd" "\0"
"xz" "\0"
"xzcat" "\0"
"yes" "\0"
"zcat" "\0"
;

#define APPLET_NO_ar 2
#define APPLET_NO_arch 3
#define APPLET_NO_ash 4
#define APPLET_NO_awk 5
#define APPLET_NO_base64 6
#define APPLET_NO_basename 7
#define APPLET_NO_bash 8
#define APPLET_NO_bunzip2 9
#define APPLET_NO_busybox 10
#define APPLET_NO_bzcat 11
#define APPLET_NO_bzip2 12
#define APPLET_NO_cal 13
#define APPLET_NO_cat 14
#define APPLET_NO_chmod 15
#define APPLET_NO_cksum 16
#define APPLET_NO_clear 17
#define APPLET_NO_cmp 18
#define APPLET_NO_comm 19
#define APPLET_NO_cp 20
#define APPLET_NO_cpio 21
#define APPLET_NO_cut 22
#define APPLET_NO_date 23
#define APPLET_NO_dc 24
#define APPLET_NO_dd 25
#define APPLET_NO_df 26
#define APPLET_NO_diff 27
#define APPLET_NO_dirname 28
#define APPLET_NO_dos2unix 29
#define APPLET_NO_dpkg 30
#define APPLET_NO_du 32
#define APPLET_NO_echo 33
#define APPLET_NO_ed 34
#define APPLET_NO_egrep 35
#define APPLET_NO_env 36
#define APPLET_NO_expand 37
#define APPLET_NO_expr 38
#define APPLET_NO_factor 39
#define APPLET_NO_false 40
#define APPLET_NO_fgrep 41
#define APPLET_NO_find 42
#define APPLET_NO_fold 43
#define APPLET_NO_fsync 44
#define APPLET_NO_ftpget 45
#define APPLET_NO_ftpput 46
#define APPLET_NO_getopt 47
#define APPLET_NO_grep 48
#define APPLET_NO_groups 49
#define APPLET_NO_gunzip 50
#define APPLET_NO_gzip 51
#define APPLET_NO_hd 52
#define APPLET_NO_head 53
#define APPLET_NO_hexdump 54
#define APPLET_NO_iconv 55
#define APPLET_NO_id 56
#define APPLET_NO_ipcalc 57
#define APPLET_NO_kill 58
#define APPLET_NO_killall 59
#define APPLET_NO_less 60
#define APPLET_NO_link 61
#define APPLET_NO_ln 62
#define APPLET_NO_logname 63
#define APPLET_NO_ls 64
#define APPLET_NO_lzcat 65
#define APPLET_NO_lzma 66
#define APPLET_NO_lzop 67
#define APPLET_NO_lzopcat 68
#define APPLET_NO_man 69
#define APPLET_NO_md5sum 70
#define APPLET_NO_mkdir 71
#define APPLET_NO_mktemp 72
#define APPLET_NO_mv 73
#define APPLET_NO_nc 74
#define APPLET_NO_nl 75
#define APPLET_NO_od 76
#define APPLET_NO_paste 77
#define APPLET_NO_patch 78
#define APPLET_NO_pgrep 79
#define APPLET_NO_pidof 80
#define APPLET_NO_pipe_progress 81
#define APPLET_NO_pkill 82
#define APPLET_NO_printenv 83
#define APPLET_NO_printf 84
#define APPLET_NO_ps 85
#define APPLET_NO_pwd 86
#define APPLET_NO_readlink 87
#define APPLET_NO_realpath 88
#define APPLET_NO_reset 89
#define APPLET_NO_rev 90
#define APPLET_NO_rm 91
#define APPLET_NO_rmdir 92
#define APPLET_NO_rpm 93
#define APPLET_NO_rpm2cpio 94
#define APPLET_NO_sed 95
#define APPLET_NO_seq 96
#define APPLET_NO_sh 97
#define APPLET_NO_sha1sum 98
#define APPLET_NO_sha256sum 99
#define APPLET_NO_sha3sum 100
#define APPLET_NO_sha512sum 101
#define APPLET_NO_shred 102
#define APPLET_NO_shuf 103
#define APPLET_NO_sleep 104
#define APPLET_NO_sort 105
#define APPLET_NO_split 106
#define APPLET_NO_ssl_client 107
#define APPLET_NO_stat 108
#define APPLET_NO_strings 109
#define APPLET_NO_su 110
#define APPLET_NO_sum 111
#define APPLET_NO_tac 112
#define APPLET_NO_tail 113
#define APPLET_NO_tar 114
#define APPLET_NO_tee 115
#define APPLET_NO_test 116
#define APPLET_NO_timeout 117
#define APPLET_NO_touch 118
#define APPLET_NO_tr 119
#define APPLET_NO_true 120
#define APPLET_NO_truncate 121
#define APPLET_NO_ts 122
#define APPLET_NO_ttysize 123
#define APPLET_NO_uname 124
#define APPLET_NO_uncompress 125
#define APPLET_NO_unexpand 126
#define APPLET_NO_uniq 127
#define APPLET_NO_unix2dos 128
#define APPLET_NO_unlink 129
#define APPLET_NO_unlzma 130
#define APPLET_NO_unlzop 131
#define APPLET_NO_unxz 132
#define APPLET_NO_unzip 133
#define APPLET_NO_usleep 134
#define APPLET_NO_uudecode 135
#define APPLET_NO_uuencode 136
#define APPLET_NO_vi 137
#define APPLET_NO_watch 138
#define APPLET_NO_wc 139
#define APPLET_NO_wget 140
#define APPLET_NO_which 141
#define APPLET_NO_whoami 142
#define APPLET_NO_whois 143
#define APPLET_NO_xargs 144
#define APPLET_NO_xxd 145
#define APPLET_NO_xz 146
#define APPLET_NO_xzcat 147
#define APPLET_NO_yes 148
#define APPLET_NO_zcat 149

#ifndef SKIP_applet_main
int (*const applet_main[])(int argc, char **argv) = {
test_main,
test_main,
ar_main,
uname_main,
ash_main,
awk_main,
base64_main,
basename_main,
ash_main,
bunzip2_main,
busybox_main,
bunzip2_main,
bzip2_main,
cal_main,
cat_main,
chmod_main,
cksum_main,
clear_main,
cmp_main,
comm_main,
cp_main,
cpio_main,
cut_main,
date_main,
dc_main,
dd_main,
df_main,
diff_main,
dirname_main,
dos2unix_main,
dpkg_main,
dpkg_deb_main,
du_main,
echo_main,
ed_main,
grep_main,
env_main,
expand_main,
expr_main,
factor_main,
false_main,
grep_main,
find_main,
fold_main,
fsync_main,
ftpgetput_main,
ftpgetput_main,
getopt_main,
grep_main,
id_main,
gunzip_main,
gzip_main,
hexdump_main,
head_main,
hexdump_main,
iconv_main,
id_main,
ipcalc_main,
kill_main,
kill_main,
less_main,
link_main,
ln_main,
logname_main,
ls_main,
unlzma_main,
unlzma_main,
lzop_main,
lzop_main,
man_main,
md5_sha1_sum_main,
mkdir_main,
mktemp_main,
mv_main,
nc_main,
nl_main,
od_main,
paste_main,
patch_main,
pgrep_main,
pidof_main,
pipe_progress_main,
pgrep_main,
printenv_main,
printf_main,
ps_main,
pwd_main,
readlink_main,
realpath_main,
reset_main,
rev_main,
rm_main,
rmdir_main,
rpm_main,
rpm2cpio_main,
sed_main,
seq_main,
ash_main,
md5_sha1_sum_main,
md5_sha1_sum_main,
md5_sha1_sum_main,
md5_sha1_sum_main,
shred_main,
shuf_main,
sleep_main,
sort_main,
split_main,
ssl_client_main,
stat_main,
strings_main,
suw32_main,
sum_main,
tac_main,
tail_main,
tar_main,
tee_main,
test_main,
timeout_main,
touch_main,
tr_main,
true_main,
truncate_main,
ts_main,
ttysize_main,
uname_main,
uncompress_main,
expand_main,
uniq_main,
dos2unix_main,
unlink_main,
unlzma_main,
lzop_main,
unxz_main,
unzip_main,
usleep_main,
uudecode_main,
uuencode_main,
vi_main,
watch_main,
wc_main,
wget_main,
which_main,
whoami_main,
whois_main,
xargs_main,
xxd_main,
unxz_main,
unxz_main,
yes_main,
gunzip_main,
};
#endif

const uint8_t applet_flags[] ALIGN1 = {
0xcf,
0xc8,
0x00,
0x88,
0x0e,
0xa2,
0x28,
0x0b,
0x0c,
0x22,
0xa3,
0x83,
0x08,
0x2a,
0xfa,
0xec,
0x02,
0xe0,
0x0a,
0x08,
0xc0,
0xfb,
0x8f,
0x03,
0xa2,
0x8a,
0x08,
0x02,
0x02,
0x33,
0xcf,
0x03,
0x0e,
0x30,
0x00,
0x3c,
0x0a,
0x02,
};

