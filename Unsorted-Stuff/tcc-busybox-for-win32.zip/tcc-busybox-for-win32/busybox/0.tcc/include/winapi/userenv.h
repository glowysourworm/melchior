WINBOOL WINAPI GetUserProfileDirectoryA (HANDLE hToken, LPSTR lpProfileDir, LPDWORD lpcchSize);
#define GetUserProfileDirectory GetUserProfileDirectoryA
