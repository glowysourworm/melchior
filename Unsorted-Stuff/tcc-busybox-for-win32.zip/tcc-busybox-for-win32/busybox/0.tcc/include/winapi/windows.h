#ifndef _WINDOWS_H
#define _WINDOWS_H

#include_next <windows.h>
#include <winnls.h>

#endif
